# cotm
A registration platform with paystack integration built on laravel.
